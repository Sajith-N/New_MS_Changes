package com.wipro.ProductMicroService.bean;

import java.sql.Date;
import java.sql.Timestamp;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ProductView {
	    private Integer id;
	    private String productName;
	    private String productCode;
	    private String productDesc;
	    private Date productAddedOn;
		private float price;
		private int promotion;
		private Timestamp startDate;
		private Timestamp endDate;
		private int quantity;
		private String supplierDetails;
		
		public String getSupplierDetails() {
			return supplierDetails;
		}
		public void setSupplierDetails(String supplierDetails) {
			this.supplierDetails = supplierDetails;
		}
		public void ProductView() {
			
		}
		public Integer getId() {
			return id;
		}
		public void setId(Integer id) {
			this.id = id;
		}
		public String getProductName() {
			return productName;
		}
		public void setProductName(String productName) {
			this.productName = productName;
		}
		public String getProductCode() {
			return productCode;
		}
		public void setProductCode(String productCode) {
			this.productCode = productCode;
		}
		public String getProductDesc() {
			return productDesc;
		}
		public void setProductDesc(String productDesc) {
			this.productDesc = productDesc;
		}
		public Date getProductAddedOn() {
			return productAddedOn;
		}
		public void setProductAddedOn(Date productAddedOn) {
			this.productAddedOn = productAddedOn;
		}
		public float getPrice() {
			return price;
		}
		public void setPrice(float price) {
			this.price = price;
		}
		public int getPromotion() {
			return promotion;
		}
		public void setPromotion(int promotion) {
			this.promotion = promotion;
		}
		
		public Timestamp getStartDate() {
			return startDate;
		}
		public void setStartDate(Timestamp startDate) {
			this.startDate = startDate;
		}
		public Timestamp getEndDate() {
			return endDate;
		}
		public void setEndDate(Timestamp endDate) {
			this.endDate = endDate;
		}
		public int getQuantity() {
			return quantity;
		}
		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		
}