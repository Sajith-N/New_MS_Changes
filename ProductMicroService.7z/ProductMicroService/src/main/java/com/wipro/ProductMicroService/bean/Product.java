package com.wipro.ProductMicroService.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Component
@Entity
@Getter
@Setter
@NoArgsConstructor
@ToString
public class Product {
	
	@Id
    @Column(name = "ID")
    private Integer id;
    private String productName;
    private String productCode;
    @Column(name = "PRODUCT_DESC")
    private String productDesc;
    public String getProductDesc() {
		return productDesc;
	}
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	public void Product()
    {
    	
    }
    public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public Date getProductAddedOn() {
		return productAddedOn;
	}
	public void setProductAddedOn(Date productAddedOn) {
		this.productAddedOn = productAddedOn;
	}
	private Date productAddedOn;

}
