/**
 * 
 */
package com.wipro.productviewms.bean;

import java.sql.Timestamp;

/**
 * @author Team 6
 *
 */


public class Promotion {

	
	private int productID;
	private int promotion;
	private Timestamp startDate;
	private Timestamp endDate;

		public int getProductID() {
		return productID;
	}

	public void setProductID(int productID) {
		this.productID = productID;
	}

	public int getPromotion() {
		return promotion;
	}

	public void setPromotion(int promotion) {
		this.promotion = promotion;
	}
	public Timestamp getStartDate() {
		return startDate;
	}
	public void setStartDate(Timestamp startDate) {
		this.startDate = startDate;
	}

	public Timestamp getEndDate() {
		return endDate;
	}

	public void setEndDate(Timestamp endDate) {
		this.endDate = endDate;
	}


}
