package com.wipro.productviewms.bean;

import java.sql.Date;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@NoArgsConstructor
@ToString
public class Product {
	
	
    private Integer id;
    private String productName;
    private String productCode;
    private String productDesc;
    private Date productAddedOn;
	public Date getProductAddedOn() {
		return productAddedOn;
	}
	public void setProductAddedOn(Date productAddedOn) {
		this.productAddedOn = productAddedOn;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductDesc() {
		return productDesc;
	}
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

}
